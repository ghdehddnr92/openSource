package member.entity;

public class PaymentEntity {
    String memberId;
    String paymentDate;
    String amount;
    
    public PaymentEntity() {
        super();
    }
    public PaymentEntity( String memberId, String paymentDate, String amount) {
        super();
        this.memberId = memberId;
        this.paymentDate = paymentDate;
        this.amount = amount;
    }
	
    public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
    
    
}
