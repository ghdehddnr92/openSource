package member.dao;

import static common.Util.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import member.entity.MemberEntity;
import member.entity.PaymentEntity;

import common.Util.JdbcUtil;

public class MemberDao {
	public int insertMember(MemberEntity member, Connection conn) throws SQLException{

		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "INSERT INTO TB_MEMBER VALUES (?, ?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getMemberId());
			pstmt.setString(2, member.getMemberName());

			result = pstmt.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally{
			close(pstmt);
		}

		return result;
	}
	public int insertPayment(PaymentEntity payment, Connection conn) throws SQLException{

		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "INSERT INTO TB_PAYMENT VALUES (?,SYSDATE,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, payment.getMemberId());
			pstmt.setString(2, payment.getAmount());

			result = pstmt.executeUpdate();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally{
			close(pstmt);
		}

		return result;
	}
	public MemberEntity loginMember(String memberId, Connection conn) throws SQLException{
		MemberEntity member = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM TB_MEMBER WHERE MEMBER_ID = ?";


		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memberId);
			rs = pstmt.executeQuery();

			if(rs.next()){
				member = new MemberEntity();
				member.setMemberId(rs.getString(1));
				member.setMemberName(rs.getString(2));
			}

			return member;
		}
		catch(SQLException e){
			e.printStackTrace();
			throw e;
		}
		finally{
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}
}
