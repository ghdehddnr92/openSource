package member.biz;

import static common.Util.JdbcUtil.close;
import static common.Util.JdbcUtil.getConnection;
import static common.Util.JdbcUtil.rollback;

import java.sql.Connection;
import java.sql.SQLException;

import common.Util.JdbcUtil;

import member.dao.MemberDao;
import member.entity.MemberEntity;
import member.entity.PaymentEntity;

public class MemberBiz {

	public int insertMember(MemberEntity member) throws SQLException{

		MemberDao dao = new MemberDao();
		Connection conn = null;
		int result =0;
		try{
			conn = getConnection();
			result = dao.insertMember(member, conn);
			JdbcUtil.commit(conn);

		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rollback(conn);
			throw e;
		} finally{
			close(conn);
		}

		return result;
	}
	public int insertPayment(PaymentEntity payment) throws SQLException{

		MemberDao dao = new MemberDao();
		Connection conn = null;
		int result =0;
		try{
			conn = getConnection();
			result = dao.insertPayment(payment, conn);
			JdbcUtil.commit(conn);

		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rollback(conn);
			throw e;
		} finally{
			close(conn);
		}

		return result;
	}
	public MemberEntity loginMember(String memberId) throws SQLException{
		MemberEntity member = null;    	
		Connection conn = null;
		MemberDao dao = new MemberDao();

		try {
			conn = getConnection();
			member = dao.loginMember(memberId, conn);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} finally {
			close(conn);
		}

		return member;
	}
}

