package member.cmd;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.biz.MemberBiz;
import member.entity.MemberEntity;

@WebServlet(urlPatterns = {"/member/MemberRegisterForm"})
public class RegisterMember extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    doPost( request, response );
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    HttpSession session = request.getSession();
	    request.setCharacterEncoding( "UTF-8" );
	   
	try{
		
		MemberBiz biz = new MemberBiz();
		MemberEntity member = new MemberEntity(request.getParameter("memberId"),request.getParameter("memberName"));
		int result = biz.insertMember(member);
	
		// TODO 
    	//로그인 후 세션에 아이디, 이름 등 회원 정보를 담아준다.
		if(result==1){				
			session.setAttribute("success", "등록에 성공했습니다.");
			response.sendRedirect( "/hangma/member/memberRegisterSuccess.jsp" );
		} else{
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute( "message", "이름이나 사원번호가 틀렸습니다. 다시 입력해주세요." );
			rd.forward( request, response );
		}

	    
	}catch(Exception e){
	    e.printStackTrace();
		RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
		request.setAttribute( "message", "[ERROR] 등록 도중 예상치 못한 문제가 발생하였습니다." );
		rd.forward( request, response );
	}
}
	
}
