package member.cmd;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.biz.MemberBiz;
import member.entity.MemberEntity;


@WebServlet(urlPatterns = {"/member/LoginMember"})
public class LoginMember extends HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost( request, response );
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		request.setCharacterEncoding( "UTF-8" );

		try{
			MemberBiz biz = new MemberBiz();
			MemberEntity member = biz.loginMember(request.getParameter("memberId"));

			// TODO 
			//로그인 후 세션에 아이디, 이름 등 회원 정보를 담아준다.
			if(member!=null){				

				session.setAttribute("loginMember", member);
				response.sendRedirect("/hangma/menu/MenuList");

			} else{
				RequestDispatcher rd = request.getRequestDispatcher( "/member/memberRegisterForm.jsp" );
	
				rd.forward( request, response );
			}


		}catch(Exception e){
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute( "message", "[ERROR] 로그인 도중 예상치 못한 문제가 발생하였습니다." );
			rd.forward( request, response );
		}
	}
}
