package menu.entity;

public class CateringEntity {

    String cateringId;
    String memberId;
    String memberName;
    String cateringDate;
    String cateringPlace;	
    String cateringDetail;
    
    public CateringEntity() {
        super();
    }
   
    public CateringEntity( String cateringId, String memberId, String memberName, String cateringDate, String cateringPlace, String cateringDetail) {
        super();
        this.cateringId = cateringId;
        this.memberId = memberId;
        this.memberName = memberName;
        this.cateringDate = cateringDate;
        this.cateringPlace = cateringPlace;
        this.cateringDetail = cateringDetail;
       
    }

	public String getCateringId() {
		return cateringId;
	}

	public void setCateringId(String cateringId) {
		this.cateringId = cateringId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getCateringDate() {
		return cateringDate;
	}

	public void setCateringDate(String cateringDate) {
		this.cateringDate = cateringDate;
	}

	public String getCateringPlace() {
		return cateringPlace;
	}

	public void setCateringPlace(String cateringPlace) {
		this.cateringPlace = cateringPlace;
	}

	public String getCateringDetail() {
		return cateringDetail;
	}

	public void setCateringDetail(String cateringDetail) {
		this.cateringDetail = cateringDetail;
	}
    
    
}
