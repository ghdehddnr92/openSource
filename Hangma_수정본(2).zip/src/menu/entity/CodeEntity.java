package menu.entity;

public class CodeEntity {

    String codeType;
    String codeCode;
    String codeName;
    
    
    public CodeEntity() {
        super();
    }
   
    public CodeEntity(String codeType, String codeCode, String codeName) {
        super();
        this.codeType = codeType;
        this.codeCode = codeCode;
        this.codeName = codeName;
       
    }

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getCodeCode() {
		return codeCode;
	}

	public void setCodeCode(String codeCode) {
		this.codeCode = codeCode;
	}

	public String getCodeName() {
		return codeName;
	}

	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}


    
    
}
