package menu.cmd;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.biz.MemberBiz;
import member.entity.PaymentEntity;

@WebServlet(urlPatterns = {"/menu/MenuOrder"})
public class MenuOrder extends HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost( request, response );
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		request.setCharacterEncoding( "UTF-8" );
		String employeeId = request.getParameter("employeeId");
		String amount = request.getParameter("totalPrice");
		MemberBiz biz = new MemberBiz();
	
		PaymentEntity payment = null;
		try{
			payment = new PaymentEntity(employeeId, "", amount);
			biz.insertPayment(payment);
			request.setAttribute("success", "주문이 완료되었습니다.");
			RequestDispatcher rd = request.getRequestDispatcher("/member/orderSuccess.jsp");
			rd.forward(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute( "message", "[ERROR] 주문 도중 예상치 못한 문제가 발생하였습니다." );
			rd.forward( request, response );
		}
	}
}
