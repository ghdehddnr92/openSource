package menu.cmd;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import menu.biz.MenuBiz;
import menu.entity.MenuEntity;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@WebServlet(urlPatterns = {"/menu/MenuRegister"})

public class MenuRegister extends HttpServlet{
	  private static final long serialVersionUID = 1L;

	  protected void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
	        doPost( request, response );
	    }

	  protected void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {


	    	// TODO 
	    	//배송 물품 등록
	    	String realPath = request.getSession().getServletContext().getRealPath("img");
	        System.out.println("realPath: " + realPath);
	        
	    	// 파일과 파라미터를 같이 처리할 수 있는 MultipartRequest로 request를 변환 // 10MB 용량 제한
	        MultipartRequest multi = new MultipartRequest(request, realPath, 1024*1024*10, "UTF-8", new DefaultFileRenamePolicy());
	        
	        request.setCharacterEncoding( "UTF-8" );

	        MenuBiz biz = new MenuBiz();
	        MenuEntity menu= new MenuEntity();
	       
	        String menuCategory = multi.getParameter("menuCategory");
	        String menuName = multi.getParameter("menuName");
	        String price = multi.getParameter("price");
	        String imgFileName = multi.getParameter("imgFileNameVal");
	        String cateringYn = multi.getParameter("cateringYn");
	        String orderSeq = multi.getParameter("orderSeq");

	        try {
	        
	        	@SuppressWarnings("rawtypes")
				Enumeration files = multi.getFileNames();
	            //mainImg
	            String realFileName = multi.getParameter( "mainImg" );
	            if (files.hasMoreElements()) {
	                String fileType = (String) files.nextElement();
	                realFileName = multi.getFilesystemName(fileType);
	                String realFilePath = realPath + "\\" + realFileName;
	                
	                // 파일 객체 가져오기
	                File file = new File(realFilePath);
	                
	                // 변경할 파일명
	                String modifyFileName = realFileName;
	                String modifyFilePath = realPath + "\\" + modifyFileName;
	                
	                // 변경해서 저장
	                file.renameTo(new File(modifyFilePath));  
	                menu.setImgFileName(realFileName); //이미지 파일네임   
	            }	
	            
	            menu.setMenuName(menuName);
	            menu.setCateringYn(cateringYn);
	            menu.setMenuCategory(menuCategory);
	            menu.setOrderSeq(orderSeq);
	            menu.setPrice(price);

	            biz.insertMenu( menu );
	            
	            RequestDispatcher rd = request.getRequestDispatcher( "/menu/MenuMgmtList" );
	            request.setAttribute( "success", "등록이 완료되었습니다.");
	            rd.forward( request, response );

	        } catch ( Exception e ) {
	            e.printStackTrace();
	            RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
	            request.setAttribute( "message", "[ERROR] 등록 중 예상치 못한 문제가 발생하였습니다." );
	            rd.forward( request, response );
	        }
	    }
}
