package menu.cmd;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import menu.biz.MenuBiz;
import menu.entity.CodeEntity;
import menu.entity.MenuEntity;

@WebServlet(urlPatterns = {"/menu/MenuMgmtDetail"})
public class MenuMgmtDetail extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost( request, response );
	}	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		request.setCharacterEncoding( "UTF-8" );
		response.setContentType("text/html;charset=UTF-8");
		MenuBiz biz = new MenuBiz();
		MenuEntity menu =null;
		String menuId = request.getParameter("menuId");
		ArrayList<CodeEntity> codes = null;
		System.out.println(menuId);
		try{
			menu = biz.selectMenu(menuId);
			codes = biz.selectMenuCategoryList();
	
			RequestDispatcher rd = request.getRequestDispatcher("/menu/MenuDetailUpdateForm.jsp");
			request.setAttribute("menu", menu);
			request.setAttribute("codeList", codes);

			rd.forward(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
			request.setAttribute( "message", "[ERROR] 메뉴관리 화면으로 넘어가던중 에러가 발생했습니다." );
			rd.forward( request, response );
		}
	}
}
