package menu.cmd;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import menu.biz.MenuBiz;
import menu.entity.MenuEntity;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@WebServlet(urlPatterns = {"/menu/MenuUpdate"})
public class MenuUpdate extends HttpServlet{
    private static final long serialVersionUID = 1L;
    protected void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
        doPost( request, response );
    }
    protected void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
    	String realPath = request.getSession().getServletContext().getRealPath("img");
        System.out.println("realPath: " + realPath);
        
    	// 파일과 파라미터를 같이 처리할 수 있는 MultipartRequest로 request를 변환 // 10MB 용량 제한
       
     //   MultipartRequest multi = new MultipartRequest(request, realPath, 1024*1024*10, "UTF-8", new DefaultFileRenamePolicy());
        request.setCharacterEncoding( "UTF-8" );
        MenuBiz biz = new MenuBiz();
        MenuEntity menu = new MenuEntity();
        
        String menuId = request.getParameter("menuId");
        String menuCategory = request.getParameter("menuCategory");
        String menuName = request.getParameter("menuName");
        String price = request.getParameter("price");
        String imgFileName = request.getParameter("imgFileNameVal");
        String cateringYn = request.getParameter("cateringYn");
        String orderSeq = request.getParameter("orderSeq");
     
        try{
        	
             
             menu.setMenuId(menuId);
             menu.setCateringYn(cateringYn);
             menu.setMenuCategory(menuCategory);
             menu.setMenuName(menuName);
             menu.setOrderSeq(orderSeq);
             menu.setPrice(price);
             menu.setImgFileName(imgFileName);
             biz.updateMenu(menu);
             RequestDispatcher rd = request.getRequestDispatcher( "/menu/menuSuccess.jsp" );
             request.setAttribute( "success", "수정이 완료되었습니다.");
             rd.forward( request, response );
        }catch ( Exception e ) {
            e.printStackTrace();
            RequestDispatcher rd = request.getRequestDispatcher( "/common/message.jsp" );
            request.setAttribute( "message", "[ERROR] 수정 중 예상치 못한 문제가 발생하였습니다." );
            rd.forward( request, response );
        }
    }
}
