package menu.dao;

import static common.Util.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import menu.entity.CateringEntity;
import menu.entity.CodeEntity;
import menu.entity.MenuEntity;

public class MenuDao {
	public ArrayList<MenuEntity> selectMenuList(Connection conn) throws SQLException{

		ArrayList<MenuEntity> list = new ArrayList<MenuEntity>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "SELECT * FROM TB_MENU";

		try{
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while(rs.next()){
				MenuEntity menu = new MenuEntity(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));

				list.add(menu);
			}
		}
		catch(SQLException e){
			throw e;
		} finally{
			close(rs);
			close(pstmt);
		}

		return list;

	}

	public ArrayList<MenuEntity> selectMenuMgmtList(Connection conn) throws SQLException{
		ArrayList<MenuEntity> list = new ArrayList<MenuEntity>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "SELECT * FROM TB_MENU";

		try{
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while(rs.next()){
				MenuEntity menu = new MenuEntity(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));

				list.add(menu);
			}
		}
		catch(SQLException e){
			throw e;
		} finally{
			close(rs);
			close(pstmt);
		}

		return list;
	}

	public ArrayList<CodeEntity> selectMenuCategoryList(Connection conn) throws SQLException{
		ArrayList<CodeEntity> list = new ArrayList<CodeEntity>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "SELECT * FROM TB_CODE";

		try{
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while(rs.next()){
				CodeEntity code = new CodeEntity(rs.getString(1),rs.getString(2),
						rs.getString(3));

				list.add(code);
			}
		}
		catch(SQLException e){
			throw e;
		} finally{
			close(rs);
			close(pstmt);
		}

		return list;
	}

	public MenuEntity selectMenu(String menuId,Connection conn) throws SQLException{
		MenuEntity menu = new MenuEntity();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "SELECT * FROM TB_MENU WHERE MENU_ID = ?";

		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, menuId);
			rs = pstmt.executeQuery();

			while(rs.next()){
				menu.setMenuId(rs.getString(1));
				menu.setMenuCategory(rs.getString(2));
				menu.setMenuName(rs.getString(3));
				menu.setPrice(rs.getString(4));
				menu.setImgFileName(rs.getString(5));
				menu.setCateringYn(rs.getString(6));
				menu.setOrderSeq(rs.getString(7));
				
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} 
		finally {
			close(rs);
			close(pstmt);
		}

		return menu;
	}

	public int updateMenu(MenuEntity menu, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		int result = 0;

		String sql = "UPDATE TB_MENU SET "
				+ " MENU_CATEGORY = ? "
				+ " ,MENU_NAME = ? "
				+ " ,PRICE = ? "
				+ " ,IMG_FILE_NAME = ? "
				+ " ,CATERING_YN = ? "
				+ " ,ORDER_SEQ = ? "
				+ " WHERE MENU_ID = ? ";

		try{
			pstmt = conn.prepareStatement(sql);

	        pstmt.setString( 1, menu.getMenuCategory() );
	        pstmt.setString( 2, menu.getMenuName());
	        pstmt.setString( 3, menu.getPrice() );
	        pstmt.setString( 4, menu.getImgFileName() );
	        pstmt.setString( 5, menu.getCateringYn() );
	        pstmt.setString( 6, menu.getOrderSeq());
			pstmt.setString( 7, menu.getMenuId() );
			result = pstmt.executeUpdate();
			
		}
		catch(SQLException e){
			e.printStackTrace();
			throw e;
		} finally{
			close(pstmt);
		}
		return result;	
	}

	public int insertMenu(MenuEntity menu ,Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		int result = 0;

//		String sql = "INSERT INTO TB_MENU VALUES ((SELECT '"+menu.getMenuCategory()+"'||'_'||LPAD(count(*)+1,3,0) FROM TB_MENU"
//				+ " WHERE MENU_CATEGORY = '"+menu.getMenuCategory()+"'), ?, ?, ?, ? ,?, ?)";
		String sql = "INSERT INTO TB_MENU VALUES ('"+menu.getMenuCategory()+"'||'_'||LPAD((SELECT count(*) FROM TB_MENU WHERE MENU_CATEGORY = '"+menu.getMenuCategory()+"')+1,3,0), ?, ?, ?, ? ,?, ?)";

		try{
			pstmt = conn.prepareStatement(sql);
		//	System.out.println("SIBAL : "+menu.getMenuCategory());
			pstmt.setString(1, menu.getMenuCategory());
			pstmt.setString(2, menu.getMenuName());
			pstmt.setString(3, menu.getPrice());
			pstmt.setString(4, menu.getImgFileName());
			pstmt.setString(5, menu.getCateringYn());
			pstmt.setString(6, menu.getOrderSeq());

			result = pstmt.executeUpdate();	

		}
		catch(SQLException e){
			e.printStackTrace();
			throw e;
		} finally{
			close(pstmt);
		}
		return result;
	}

	public ArrayList<CateringEntity> selectCateringList(Connection conn) throws SQLException{
		ArrayList<CateringEntity> list = new ArrayList<CateringEntity>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql = "SELECT * "
				+ "FROM TB_CATERING C, TB_MEMBER M"
				+ " WHERE C.MEMBER_ID = M.MEMBER_ID";

		try{
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while(rs.next()){
				CateringEntity code = new CateringEntity(rs.getString("CATERING_ID"),rs.getString("MEMBER_ID"),
						rs.getString("MEMBER_NAME"),rs.getString("CATERING_DATE"),rs.getString("CATERING_PLACE"),rs.getString("CATERING_DETAIL"));

				list.add(code);
			}
		}
		catch(SQLException e){
			throw e;
		} finally{
			close(rs);
			close(pstmt);
		}

		return list;
	}

	public int insertCateringList(CateringEntity catering, Connection conn) throws SQLException{

		PreparedStatement pstmt = null;
		int result = 0;

		String sql = "INSERT INTO TB_CATERING VALUES ((SELECT TO_CHAR(SYSDATE, 'YYYYMMDD')||'_'||LPAD(count(*)+1,3,0) FROM TB_CATERING),?, ?, ? ,?)";

		try{
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, catering.getMemberId());
			pstmt.setString(2, catering.getCateringDate());
			pstmt.setString(3, catering.getCateringDetail());
			pstmt.setString(4, catering.getCateringPlace());

			result = pstmt.executeUpdate();

		}
		catch(SQLException e){
			e.printStackTrace();
			throw e;
		} finally{
			close(pstmt);
		}
		return result;
	}
}
