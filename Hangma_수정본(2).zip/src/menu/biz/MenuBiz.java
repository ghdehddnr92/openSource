package menu.biz;

import static common.Util.JdbcUtil.close;
import static common.Util.JdbcUtil.commit;
import static common.Util.JdbcUtil.getConnection;
import static common.Util.JdbcUtil.rollback;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import menu.dao.MenuDao;
import menu.entity.CateringEntity;
import menu.entity.CodeEntity;
import menu.entity.MenuEntity;

import common.Util.JdbcUtil;

public class MenuBiz {

	public ArrayList<MenuEntity> selectMenuList() throws SQLException{
		ArrayList<MenuEntity> list = new ArrayList<MenuEntity>();
		MenuDao dao = new MenuDao();
		Connection conn = null;

		try{
			conn = JdbcUtil.getConnection();
			list = dao.selectMenuList(conn);
		}catch(SQLException e){
			throw e;
		} finally{
			close(conn);
		}

		return list;
	}

	public ArrayList<MenuEntity> selectMenuMgmtList() throws SQLException{
		ArrayList<MenuEntity> list = new ArrayList<MenuEntity>();
		MenuDao dao = new MenuDao();
		Connection conn = null;

		try{
			conn = JdbcUtil.getConnection();
			list = dao.selectMenuList(conn);
		}catch(SQLException e){
			throw e;
		} finally{
			close(conn);
		}

		return list;	
	}
	public ArrayList<CodeEntity> selectMenuCategoryList() throws SQLException{
		ArrayList<CodeEntity> list = new ArrayList<CodeEntity>();
		MenuDao dao = new MenuDao();
		Connection conn = null;

		try{
			conn = JdbcUtil.getConnection();
			list = dao.selectMenuCategoryList(conn);
		}catch(SQLException e){
			throw e;
		} finally{
			close(conn);
		}

		return list;
	}
	public MenuEntity selectMenu(String menuId) throws SQLException{
		MenuDao dao = new MenuDao();
		Connection conn = null;
		MenuEntity menu = null;
		try {
			conn = getConnection();
			menu = dao.selectMenu(menuId, conn);
			commit(conn);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rollback(conn);
			throw e;
		} finally{
			close(conn);
		}

		return menu;
	}
	public int updateMenu(MenuEntity menu) throws SQLException{
		MenuDao dao = new MenuDao();
		Connection conn = null;
		int result;
		try {
			conn = getConnection();
			result = dao.updateMenu(menu, conn);
			commit(conn);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rollback(conn);
			throw e;
		} finally{
			close(conn);
		}

		return result;
	}
	public int insertMenu(MenuEntity menu) throws SQLException{
		MenuDao dao = new MenuDao();
		Connection conn = null;
		int result;
		try {
			conn = getConnection();
			result = dao.insertMenu(menu, conn);
			commit(conn);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rollback(conn);
			throw e;
		} finally{
			close(conn);
		}

		return result;
	}
	public ArrayList<CateringEntity> selectCateringList() throws SQLException{
		ArrayList<CateringEntity> list = new ArrayList<CateringEntity>();
		MenuDao dao = new MenuDao();
		Connection conn = null;

		try{
			conn = JdbcUtil.getConnection();
			list = dao.selectCateringList(conn);
		}catch(SQLException e){
			throw e;
		} finally{
			close(conn);
		}

		return list;
	}
	public int insertCateringList(CateringEntity catering) throws SQLException{
		MenuDao dao = new MenuDao();
		Connection conn = null;
		int result = 0;

		try {
			conn = getConnection();
			result = dao.insertCateringList(catering, conn);
			commit(conn);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rollback(conn);
			throw e;
		} finally{
			close(conn);
		}

		return result;
	}
}
