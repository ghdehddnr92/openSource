$(document).ready(function(){

	//When page loads...
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content
	$("#catering").hide();

	//On Click Event
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content

		if(activeTab == "#tab_cat") {

			$("#order").hide();
			$("#catering").show();

		}else {
			$("#order").show();
			$("#catering").hide();
		}

		return false;
	});


	$("#orderList").on("click", "span", function() {
		//수강생 작성
		$(this).closest("tr").remove(); 

		var price = $("#totalPrice").val();
		price = price - $(this).parent().prev().text();
		$("#totalPrice").val(price);
	});

	$("#orderBtn").click(function(){
		$('#orderMenu').attr("style", "display: inline-block; margin:0px");
		$('.modal-body').attr("style", "color : #000;");
		$('.modal-body').html("주문하시겠습니까?");
	});

	$("#orderMenu").click(function() { 
		if($('#totalPrice').val()== 0 || $('#totalPrice').val()==""){
			$('.modal-body').attr("style", "color : #f14444");
			$('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 메뉴를 선택해 주세요.");
			$('#orderMenu').attr("style", "display: none");
			return;
		}

		if($('#employeeId').val()== ""){
			$('.modal-body').attr("style", "color : #f14444");
			$('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 사번을 입력해 주세요.");
			$('#orderMenu').attr("style", "display: none");
			return;
		}

		$('#menuOrderForm').submit();
	});

	$("#submitBtn").click(function(){
		
		if($('#orderId').val()==""){
			$('.modal-body').attr("style", "color : #f14444");
			$('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 주문내용을 입력해 주세요.");
			$('#orderMenu').attr("style", "display: none");
			return;
		}
		else if($('#locationId').val()==""){
			$('.modal-body').attr("style", "color : #f14444");
			$('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 케이터링 장소을 입력해 주세요.");
			$('#orderMenu').attr("style", "display: none");
			return;
		}
		else if($('#locationDate').val()==""){
			$('.modal-body').attr("style", "color : #f14444");
			$('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 케이터링 일시를 입력해 주세요.");
			$('#orderMenu').attr("style", "display: none");
			return;
		}
		else if($('#memberInputId').val()==""){
			$('.modal-body').attr("style", "color : #f14444");
			$('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 사번을 입력해 주세요.");
			$('#orderMenu').attr("style", "display: none");
			return;
		}
		
		
	})
	$('#caterMenu').click(function(){
		$('#cateringOrderForm').submit();	
	})

});


function menuClick(menuId, menuName, price) {

	//메뉴 주문 리스트에 추가하는 부분 구현
	var row = "<tr>"; 
	row += "<td>" + menuName +"</td>"; 
	row += "<td style='text-align:right'>"+ 1 +"</td>"; 
	row += "<td style='text-align:right'>"+ price +"</td>"; 
	row += "<td style='text-align:center'><span>삭제</span></td>"; 
	row += "</tr>"; 

	$("#orderList").append(row); 
	var totalPrice = !$("#totalPrice").val() ? 0 : $("#totalPrice").val();
	totalPrice = parseInt(totalPrice) + parseInt(price);

	var totalPriceRow = "<tr>"; 
	totalPriceRow += "<td style='text-align:right' colspan='4'>" + totalPrice +" 원</td>"; 
	totalPriceRow += "</tr>"; 

	$("#totalPrice").val(totalPrice); 

}

function getContextPath() {
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};
