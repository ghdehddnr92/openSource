$(document).ready(function(){
	
	$("#basicModalButton").click(function(){
    	$('#updateMenu').attr("style", "display: inline-block; margin:0px");
    	$('.modal-body').attr("style", "color : #000;");
    	$('.modal-body').html("저장하시겠습니까?");
    });
    
	
	$('#updateMenu').click(function () {
		
		
		if($('#menuName').val()== ""){
			 $('.modal-body').attr("style", "color : #f14444");
			 $('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 메뉴명을 입력해 주세요.");
			 $('#updateMenu').attr("style", "display: none");
			 return;
		}else if($('#menuCategory').val()== ""){
			 $('.modal-body').attr("style", "color : #f14444");
			 $('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 분류를 선택해 주세요.");
			 $('#updateMenu').attr("style", "display: none");
			 return;
		}else if($('#price').val()== ""){
			 $('.modal-body').attr("style", "color : #f14444");
			 $('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 가격을 입력해 주세요.");
			 $('#updateMenu').attr("style", "display: none");
			 return;
		}else if($('#cateringYn').val()== ""){
			 $('.modal-body').attr("style", "color : #f14444");
			 $('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 케이터링 가능 여부를 입력해 주세요.");
			 $('#updateMenu').attr("style", "display: none");
			 return;
		}else if($('#orderSeq').val()== ""){
			 $('.modal-body').attr("style", "color : #f14444");
			 $('.modal-body').html("<i class='glyphicon glyphicon-remove-circle'></i> 정렬 순서를 입력해 주세요.");
			 $('#updateMenu').attr("style", "display: none");
			 return;
		}
		
		$('#menuUpdateForm').submit();
		
	});
	
	
});


//ContextPath 구하는 함수
function getContextPath() {
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};



