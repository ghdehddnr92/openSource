$(document).ready(function(){

	$("#loginButton").on("click", function() { 
    	
    	if($('#memberId').val()== ""){
			 alert("사번을 입력해 주세요.");
			 return;
		}
    	
    	$('#loginForm').submit();
    });

	
});


// ContextPath 구하는 함수
function getContextPath() {
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};