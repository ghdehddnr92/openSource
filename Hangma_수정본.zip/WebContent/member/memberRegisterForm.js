var idCheck = false;
var nameCheck = false;

$(document).ready(function(){
	
	
	
	//basicModalButton
	$('#basicModalButton').click(function () {
		
		//유효성 체크 부분 작성
		
		
		$('#registMemberButton').attr("style", "display: inline-block; margin:0px");
		$('#modalBody').attr("style", "color : #000;");
		$('#modalBody').html("등록 하시겠습니까?");
	
	});
	//resistuserButton
	$('#registMemberButton').click(function () {
		
		//유효성 체크 부분 작성
		
			$('#registerMember').submit();

	});
	
});



function getContextPath() {
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};