$(document).ready(function(){
	
	$("#submitBtn").click(function(){
		$("#formSearch").submit();
	})
});


function getContextPath() {
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};
