package menu.entity;

public class MenuEntity {

    String menuId;
    String menuCategory;
    String menuName;
    String price;
    String imgFileName;
    String cateringYn;
    String orderSeq;
    
    
    public MenuEntity() {
        super();
    }
   
    public MenuEntity( String menuId, String menuCategory, String menuName, String price, String imgFileName, String cateringYn, String orderSeq) {
        super();
        this.menuId = menuId;
        this.menuCategory = menuCategory;
        this.menuName = menuName;
        this.price = price;
        this.imgFileName = imgFileName;
        this.cateringYn = cateringYn;
        this.orderSeq = orderSeq;
       
    }

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getMenuCategory() {
		return menuCategory;
	}

	public void setMenuCategory(String menuCategory) {
		this.menuCategory = menuCategory;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getImgFileName() {
		return imgFileName;
	}

	public void setImgFileName(String imgFileName) {
		this.imgFileName = imgFileName;
	}

	public String getCateringYn() {
		return cateringYn;
	}

	public void setCateringYn(String cateringYn) {
		this.cateringYn = cateringYn;
	}

	public String getOrderSeq() {
		return orderSeq;
	}

	public void setOrderSeq(String orderSeq) {
		this.orderSeq = orderSeq;
	}


    
    
}
