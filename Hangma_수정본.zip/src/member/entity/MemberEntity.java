package member.entity;

public class MemberEntity {
    String memberId;
    String memberName;
    
    public MemberEntity() {
        super();
    }
    public MemberEntity( String memberId, String memberName) {
        super();
        this.memberId = memberId;
        this.memberName = memberName;
    }
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	
    
   
    
    
    
}
